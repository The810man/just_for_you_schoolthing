"""
Kreditberechnung-Modul – JustForYou
Laufzeitbibliothek: Kreditberechnung mit 3 Funktionen
Finanzrechnung: mindestens 6 Nachkommastellen intern, Ausgabe währungsrichtig (2 Dezimalstellen)
"""
import math


def kredit_einmalig(kreditbetrag: float, zinssatz: float, laufzeit: float) -> dict:
    """
    Kredit mit einmaliger Rückzahlung (einfache Verzinsung).
    zinssatz: Prozent p.a., laufzeit: Monate
    """
    zinsen = kreditbetrag * (zinssatz / 100) * (laufzeit / 12)
    rueckzahlung = kreditbetrag + zinsen
    return {
        "Kreditbetrag": f"{kreditbetrag:.2f} €",
        "Zinssatz": f"{zinssatz} % p.a.",
        "Laufzeit": f"{int(laufzeit)} Monate",
        "Zinsen gesamt": f"{zinsen:.2f} €",
        "Rückzahlungsbetrag": f"{rueckzahlung:.2f} €",
        "history": (
            f"Kredit (einmalig): {kreditbetrag:.2f} €, {zinssatz}% p.a., "
            f"{int(laufzeit)} Monate → Rückzahlung {rueckzahlung:.2f} €, "
            f"Zinsen {zinsen:.2f} €"
        )
    }


def ratenkredit_laufzeit(kreditbetrag: float, zinssatz: float, laufzeit: float) -> dict:
    """
    Annuitätendarlehen mit vorgegebener Laufzeit.
    Rate = K * r * (1+r)^n / ((1+r)^n - 1), r = p/12/100
    """
    r = zinssatz / 100 / 12
    n = int(laufzeit)
    if r == 0:
        rate = kreditbetrag / n
    else:
        rate = kreditbetrag * r * (1 + r)**n / ((1 + r)**n - 1)

    zinsen_gesamt = rate * n - kreditbetrag

    return {
        "Kreditbetrag": f"{kreditbetrag:.2f} €",
        "Zinssatz": f"{zinssatz} % p.a.",
        "Laufzeit": f"{n} Monate",
        "Monatliche Rate": f"{rate:.2f} €",
        "Zinsen gesamt": f"{zinsen_gesamt:.2f} €",
        "history": (
            f"Ratenkredit: {kreditbetrag:.2f} €, {zinssatz}%, {n} Monate → "
            f"Rate {rate:.2f} €, Zinsen gesamt {zinsen_gesamt:.2f} €"
        )
    }


def ratenkredit_rate(kreditbetrag: float, zinssatz: float, rate: float) -> dict:
    """
    Annuitätendarlehen mit vorgegebener Rate. Berechnet Laufzeit.
    n = -ln(1 - K*r/R) / ln(1+r)
    """
    r = zinssatz / 100 / 12
    if r > 0 and kreditbetrag * r >= rate:
        raise ValueError(f"Rate muss größer als {kreditbetrag * r:.2f} € sein")

    if r == 0:
        n_exakt = kreditbetrag / rate
    else:
        n_exakt = -math.log(1 - kreditbetrag * r / rate) / math.log(1 + r)

    n_voll = math.floor(n_exakt)

    # Schlussrate berechnen
    rest = kreditbetrag
    for _ in range(n_voll):
        rest = rest * (1 + r) - rate

    schlussrate = rest * (1 + r) if rest > 0.005 else 0.0
    laufzeit_gesamt = n_voll + (1 if schlussrate > 0.005 else 0)
    zinsen_gesamt = rate * n_voll + schlussrate - kreditbetrag

    return {
        "Kreditbetrag": f"{kreditbetrag:.2f} €",
        "Zinssatz": f"{zinssatz} % p.a.",
        "Monatliche Rate": f"{rate:.2f} €",
        "Laufzeit": f"{laufzeit_gesamt} Monate",
        "Schlussrate": f"{schlussrate:.2f} €" if schlussrate > 0.005 else "wie normale Rate",
        "Zinsen gesamt": f"{zinsen_gesamt:.2f} €",
        "history": (
            f"Ratenkredit: {kreditbetrag:.2f} €, {zinssatz}%, Rate {rate:.2f} € → "
            f"{laufzeit_gesamt} Monate, Zinsen {zinsen_gesamt:.2f} €"
        )
    }


def calculate(function_id: str, params: dict) -> dict:
    functions = {
        "kredit_einmalig": lambda p: kredit_einmalig(
            float(p["kreditbetrag"]), float(p["zinssatz"]), float(p["laufzeit"])
        ),
        "ratenkredit_laufzeit": lambda p: ratenkredit_laufzeit(
            float(p["kreditbetrag"]), float(p["zinssatz"]), float(p["laufzeit"])
        ),
        "ratenkredit_rate": lambda p: ratenkredit_rate(
            float(p["kreditbetrag"]), float(p["zinssatz"]), float(p["rate"])
        ),
    }
    if function_id not in functions:
        raise ValueError(f"Unbekannte Funktion: {function_id}")
    return functions[function_id](params)
