"""
Prozentrechnung-Modul – JustForYou
Laufzeitbibliothek: Prozentrechnung mit 6 Funktionen
"""

def prozent_dazu(grundwert: float, prozentsatz: float) -> dict:
    """Berechnet Grundwert + Prozentwert."""
    prozentwert = grundwert * prozentsatz / 100
    ergebnis = grundwert + prozentwert
    return {
        "Prozentwert": round(prozentwert, 6),
        "Ergebnis": round(ergebnis, 6),
        "history": f"Prozent dazu: {grundwert} + {prozentsatz}% = {round(ergebnis, 6)}"
    }

def prozent_weg(grundwert: float, prozentsatz: float) -> dict:
    """Berechnet Grundwert - Prozentwert."""
    prozentwert = grundwert * prozentsatz / 100
    ergebnis = grundwert - prozentwert
    return {
        "Prozentwert": round(prozentwert, 6),
        "Ergebnis": round(ergebnis, 6),
        "history": f"Prozent weg: {grundwert} - {prozentsatz}% = {round(ergebnis, 6)}"
    }

def prozent_davon(grundwert: float, prozentsatz: float) -> dict:
    """Berechnet den Prozentwert (p% von G)."""
    ergebnis = grundwert * prozentsatz / 100
    return {
        "Prozentwert": round(ergebnis, 6),
        "history": f"Prozent davon: {prozentsatz}% von {grundwert} = {round(ergebnis, 6)}"
    }

def prozent_satz(grundwert: float, prozentwert: float) -> dict:
    """Berechnet den Prozentsatz (W/G * 100)."""
    if grundwert == 0:
        raise ValueError("Grundwert darf nicht 0 sein")
    p = prozentwert / grundwert * 100
    return {
        "Prozentsatz": f"{round(p, 6)} %",
        "history": f"Prozentsatz: {prozentwert} von {grundwert} = {round(p, 6)} %"
    }

def brutto_aus_netto(netto: float, mwst: float) -> dict:
    """Berechnet Bruttopreis aus Nettopreis und MwSt-Satz."""
    brutto = netto * (1 + mwst / 100)
    steuer = brutto - netto
    return {
        "Mehrwertsteuer": f"{round(steuer, 2)} €",
        "Bruttopreis": f"{round(brutto, 2)} €",
        "history": f"Brutto aus Netto: {netto:.2f} € + {mwst}% = {brutto:.2f} €"
    }

def netto_aus_brutto(brutto: float, mwst: float) -> dict:
    """Berechnet Nettopreis aus Bruttopreis und MwSt-Satz."""
    netto = brutto / (1 + mwst / 100)
    steuer = brutto - netto
    return {
        "Mehrwertsteuer": f"{round(steuer, 2)} €",
        "Nettopreis": f"{round(netto, 2)} €",
        "history": f"Netto aus Brutto: {brutto:.2f} € - {mwst}% = {netto:.2f} €"
    }

def calculate(function_id: str, params: dict) -> dict:
    """Dispatch-Funktion für alle Prozentrechnung-Funktionen."""
    functions = {
        "prozent_dazu": lambda p: prozent_dazu(float(p["grundwert"]), float(p["prozentsatz"])),
        "prozent_weg": lambda p: prozent_weg(float(p["grundwert"]), float(p["prozentsatz"])),
        "prozent_davon": lambda p: prozent_davon(float(p["grundwert"]), float(p["prozentsatz"])),
        "prozent_satz": lambda p: prozent_satz(float(p["grundwert"]), float(p["prozentwert"])),
        "brutto_aus_netto": lambda p: brutto_aus_netto(float(p["netto"]), float(p["mwst"])),
        "netto_aus_brutto": lambda p: netto_aus_brutto(float(p["brutto"]), float(p["mwst"])),
    }
    if function_id not in functions:
        raise ValueError(f"Unbekannte Funktion: {function_id}")
    return functions[function_id](params)
