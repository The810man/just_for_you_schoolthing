"""
Schule-Modul – JustForYou
Laufzeitbibliothek: Zeugnisnoten-Empfehlung
"""


def zeugnisnoten(noten: list) -> dict:
    """
    Berechnet Notendurchschnitt und empfiehlt Zeugnisnote.
    noten: Liste von Noten (1–6). Werte 0 oder außerhalb [1,6] werden ignoriert.
    """
    gueltige = [n for n in noten if 1 <= n <= 6]
    if not gueltige:
        raise ValueError("Keine gültigen Noten eingegeben (1–6)")

    summe = sum(gueltige)
    durchschnitt = summe / len(gueltige)
    zeugnisnote = round(durchschnitt)
    zeugnisnote = max(1, min(6, zeugnisnote))

    bezeichnungen = {1: "sehr gut", 2: "gut", 3: "befriedigend",
                     4: "ausreichend", 5: "mangelhaft", 6: "ungenügend"}

    return {
        "Anzahl Fächer": str(len(gueltige)),
        "Notendurchschnitt": f"{durchschnitt:.4f}",
        "Zeugnisnote": f"{zeugnisnote} ({bezeichnungen[zeugnisnote]})",
        "history": (
            f"Zeugnis: {len(gueltige)} Noten, "
            f"Ø {durchschnitt:.4f} → Note {zeugnisnote} ({bezeichnungen[zeugnisnote]})"
        )
    }


def calculate(function_id: str, params: dict) -> dict:
    if function_id == "zeugnisnoten":
        noten = []
        i = 1
        while f"note_{i}" in params:
            try:
                noten.append(float(params[f"note_{i}"]))
            except (ValueError, TypeError):
                pass
            i += 1
        return zeugnisnoten(noten)
    raise ValueError(f"Unbekannte Funktion: {function_id}")
