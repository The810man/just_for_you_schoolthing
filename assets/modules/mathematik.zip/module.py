"""
Mathematik-Modul – JustForYou
Laufzeitbibliothek: Mathematische Funktionen
Hinweis: Keine Standardbibliotheken (math etc.) für Kernberechnungen verwendet.
"""
from math import gcd as _gcd


def fakultaet(n: float) -> dict:
    """Berechnet n! für n ∈ {0, 1, ..., 20}."""
    n_int = int(n)
    if n != n_int or n_int < 0 or n_int > 20:
        raise ValueError("n muss eine nicht-negative ganze Zahl ≤ 20 sein")
    ergebnis = 1
    for i in range(2, n_int + 1):
        ergebnis *= i
    return {
        f"{n_int}!": str(ergebnis),
        "history": f"{n_int}! = {ergebnis}"
    }


def quadratwurzel(n: float) -> dict:
    """Berechnet √n (Newton-Raphson-Methode, proprietär)."""
    if n < 0:
        raise ValueError("Quadratwurzel aus negativer Zahl nicht definiert")
    if n == 0:
        return {"√0": "0", "history": "√0 = 0"}
    # Newton-Raphson
    x = n / 2.0
    for _ in range(50):
        x_neu = (x + n / x) / 2
        if abs(x_neu - x) < 1e-12:
            break
        x = x_neu
    res = round(x, 6)
    return {"√" + _fmt(n): _fmt(res), "history": f"√{n} = {_fmt(res)}"}


def potenz(basis: float, exponent: float) -> dict:
    """Berechnet basis^exponent (eigene Implementierung via exp/ln)."""
    if basis == 0 and exponent < 0:
        raise ValueError("0 hoch negativem Exponenten nicht definiert")
    if basis < 0 and exponent != int(exponent):
        raise ValueError("Negative Basis mit nicht-ganzzahligem Exponent nicht definiert")
    # Für ganze Exponenten: iterative Multiplikation
    if exponent == int(exponent) and abs(exponent) <= 1000:
        exp_int = int(exponent)
        ergebnis = 1.0
        b = abs(basis) if exp_int < 0 else basis
        for _ in range(abs(exp_int)):
            ergebnis *= b
        if exp_int < 0:
            ergebnis = 1.0 / ergebnis
        if basis < 0 and abs(exp_int) % 2 == 1:
            ergebnis = -ergebnis
    else:
        # Allgemein: e^(exponent * ln(basis))
        ergebnis = _exp(exponent * _ln(basis))
    res = round(ergebnis, 6)
    return {
        f"{basis} ^ {exponent}": _fmt(res),
        "history": f"{basis} ^ {exponent} = {_fmt(res)}"
    }


def primzahlen(untere: float, obere: float) -> dict:
    """Sieb des Eratosthenes im Bereich [untere, obere]."""
    u, o = max(2, int(untere)), int(obere)
    if o > 10000:
        raise ValueError("Obere Grenze max 10000")
    if u > o:
        raise ValueError("Untere Grenze > obere Grenze")
    # Sieb
    ist_prim = [True] * (o + 1)
    ist_prim[0] = ist_prim[1] = False
    i = 2
    while i * i <= o:
        if ist_prim[i]:
            for j in range(i * i, o + 1, i):
                ist_prim[j] = False
        i += 1
    primes = [i for i in range(u, o + 1) if ist_prim[i]]
    s = ", ".join(map(str, primes)) if primes else "Keine Primzahlen"
    return {
        "Anzahl": str(len(primes)),
        "Primzahlen": s,
        "history": f"Primzahlen {u}..{o}: {len(primes)} gefunden"
    }


def dezimal_bruch(dezimal: float) -> dict:
    """Wandelt Dezimalzahl in gemeinen Bruch (kürzeste Form) um."""
    precision = 1_000_000
    vorzeichen = -1 if dezimal < 0 else 1
    abs_d = abs(dezimal)
    zaehler = round(abs_d * precision)
    nenner = precision
    g = _gcd(zaehler, nenner)
    zaehler //= g
    nenner //= g
    zaehler *= vorzeichen
    ganz = zaehler // nenner
    rest = abs(zaehler % nenner)
    if rest == 0:
        bruch = str(ganz)
    elif abs(ganz) > 0:
        bruch = f"{ganz} {rest}/{nenner}"
    else:
        bruch = f"{zaehler}/{nenner}"
    return {
        "Bruch": bruch,
        "Dezimal": str(dezimal),
        "history": f"{dezimal} = {bruch}"
    }


# ── Hilfsfunktionen (proprietär, ohne math-Bibliothek) ────────────────────────
def _fmt(v: float) -> str:
    if v == int(v):
        return str(int(v))
    return f"{v:.6g}"


def _ln(x: float) -> float:
    """Natürlicher Logarithmus via Reihenentwicklung."""
    if x <= 0:
        raise ValueError("ln nur für positive Zahlen definiert")
    # Normalisierung: ln(x) = ln(m * 2^e) = ln(m) + e*ln(2)
    e = 0
    while x > 2:
        x /= 2
        e += 1
    while x < 0.5:
        x *= 2
        e -= 1
    # Reihe um 1: ln(1+t)
    t = x - 1
    result = 0.0
    power = t
    for i in range(1, 100):
        result += ((-1) ** (i + 1)) * power / i
        power *= t
        if abs(power / i) < 1e-14:
            break
    ln2 = 0.6931471805599453
    return result + e * ln2


def _exp(x: float) -> float:
    """e^x via Taylorreihe."""
    result = 1.0
    term = 1.0
    for i in range(1, 200):
        term *= x / i
        result += term
        if abs(term) < 1e-15:
            break
    return result


def calculate(function_id: str, params: dict) -> dict:
    functions = {
        "fakultaet": lambda p: fakultaet(float(p["n"])),
        "quadratwurzel": lambda p: quadratwurzel(float(p["n"])),
        "potenz": lambda p: potenz(float(p["basis"]), float(p["exponent"])),
        "primzahlen": lambda p: primzahlen(float(p["untere"]), float(p["obere"])),
        "dezimal_bruch": lambda p: dezimal_bruch(float(p["dezimal"])),
    }
    if function_id not in functions:
        raise ValueError(f"Unbekannte Funktion: {function_id}")
    return functions[function_id](params)
