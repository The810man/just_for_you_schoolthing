"""
Informationstechnik-Modul – JustForYou
Laufzeitbibliothek: Grafikspeicher, Videodateigröße, Zahlensysteme, Datenmengen
"""


def _format_bytes(bytes_val: float) -> str:
    """Gibt Wert in techniküblicher Binär-Einheit aus."""
    if bytes_val < 1024:
        return f"{bytes_val:.2f} B"
    kib = bytes_val / 1024
    if kib < 1024:
        return f"{kib:.6g} KiB"
    mib = kib / 1024
    if mib < 1024:
        return f"{mib:.6g} MiB"
    gib = mib / 1024
    return f"{gib:.6g} GiB"


def grafikspeicher(breite: float, hoehe: float, farbtiefe: float) -> dict:
    """
    Berechnet den Grafikspeicherbedarf eines Bildes.
    Farbtiefe in Bit/Pixel.
    """
    bits = breite * hoehe * farbtiefe
    byte_val = bits / 8
    return {
        "Auflösung": f"{int(breite)} × {int(hoehe)} px",
        "Farbtiefe": f"{int(farbtiefe)} Bit",
        "Bits gesamt": f"{int(bits)} bit",
        "Grafikspeicher": _format_bytes(byte_val),
        "Grafikspeicher (Byte)": f"{int(byte_val)} B",
        "history": (
            f"Grafik: {int(breite)}×{int(hoehe)} px, {int(farbtiefe)} bit "
            f"= {_format_bytes(byte_val)}"
        )
    }


def videodateigröße(breite: float, hoehe: float, farbtiefe: float,
                    fps: float, sekunden: float) -> dict:
    """Berechnet unkomprimierte Videodateigröße."""
    bits_frame = breite * hoehe * farbtiefe
    byte_frame = bits_frame / 8
    total_bytes = byte_frame * fps * sekunden
    return {
        "Auflösung": f"{int(breite)} × {int(hoehe)} px",
        "Farbtiefe": f"{int(farbtiefe)} Bit",
        "Framerate": f"{fps} fps",
        "Länge": f"{sekunden} s",
        "Speicher/Frame": _format_bytes(byte_frame),
        "Videodateigröße": _format_bytes(total_bytes),
        "history": (
            f"Video: {int(breite)}×{int(hoehe)}, {int(farbtiefe)} bit, "
            f"{fps} fps, {sekunden} s = {_format_bytes(total_bytes)}"
        )
    }


def zahlensystem(zahl: float, quell_basis: int) -> dict:
    """
    Konvertiert eine Zahl aus der Quellbasis in Dezimal, Binär, Ternär, Oktal.
    Eingabe: Dezimalwert der Zahl (bei Basis 10), oder Ziffernfolge für andere Basen.
    """
    # Für Basis 10: direkt als Integer nehmen
    z_int = int(zahl)

    if quell_basis != 10:
        # Ziffern von z_int in Quellbasis interpretieren
        s = str(z_int)
        dezimal = 0
        for c in s:
            d = int(c)
            if d >= quell_basis:
                raise ValueError(f"Ziffer '{c}' ungültig für Basis {quell_basis}")
            dezimal = dezimal * quell_basis + d
    else:
        dezimal = z_int

    def to_base(n: int, base: int) -> str:
        if n == 0:
            return "0"
        digits = []
        while n > 0:
            digits.append(str(n % base))
            n //= base
        return "".join(reversed(digits))

    return {
        "Dezimal (Basis 10)": str(dezimal),
        "Binär (Basis 2)": to_base(dezimal, 2),
        "Ternär (Basis 3)": to_base(dezimal, 3),
        "Oktal (Basis 8)": to_base(dezimal, 8),
        "history": (
            f"{z_int} (Basis {quell_basis}) → "
            f"Dez: {dezimal}, Bin: {to_base(dezimal, 2)}, "
            f"Tern: {to_base(dezimal, 3)}, Okt: {to_base(dezimal, 8)}"
        )
    }


def datenmenge(wert: float, einheit_idx: int) -> dict:
    """Rechnet Datenmenge zwischen Binär- und Dezimalpräfixen um."""
    einheiten = ["bit", "Byte", "KiB", "MiB", "GiB", "TiB", "KB", "MB", "GB", "TB"]
    faktoren_bits = {
        "bit": 1,
        "Byte": 8,
        "KiB": 8 * 1024,
        "MiB": 8 * 1024**2,
        "GiB": 8 * 1024**3,
        "TiB": 8 * 1024**4,
        "KB": 8 * 1000,
        "MB": 8 * 1000**2,
        "GB": 8 * 1000**3,
        "TB": 8 * 1000**4,
    }
    einheit = einheiten[min(einheit_idx, len(einheiten) - 1)]
    total_bits = wert * faktoren_bits[einheit]
    total_bytes = total_bits / 8

    def fmt(v: float) -> str:
        return f"{v:.6g}"

    return {
        "Einheit": einheit,
        "bit": fmt(total_bits),
        "Byte": fmt(total_bytes),
        "KiB (binär)": fmt(total_bytes / 1024),
        "MiB (binär)": fmt(total_bytes / 1024**2),
        "GiB (binär)": fmt(total_bytes / 1024**3),
        "KB (dezimal)": fmt(total_bytes / 1000),
        "MB (dezimal)": fmt(total_bytes / 1000**2),
        "GB (dezimal)": fmt(total_bytes / 1000**3),
        "history": (
            f"{wert} {einheit} = {fmt(total_bytes / 1024**2)} MiB "
            f"= {fmt(total_bytes / 1000**2)} MB"
        )
    }


def calculate(function_id: str, params: dict) -> dict:
    functions = {
        "grafikspeicher": lambda p: grafikspeicher(
            float(p["breite"]), float(p["hoehe"]), float(p["farbtiefe"])
        ),
        "videodatei": lambda p: videodateigröße(
            float(p["breite"]), float(p["hoehe"]), float(p["farbtiefe"]),
            float(p["fps"]), float(p["sekunden"])
        ),
        "zahlensystem": lambda p: zahlensystem(
            float(p["zahl"]), int(float(p["basis"]))
        ),
        "datenmenge": lambda p: datenmenge(
            float(p["wert"]), int(float(p["einheit_idx"]))
        ),
    }
    if function_id not in functions:
        raise ValueError(f"Unbekannte Funktion: {function_id}")
    return functions[function_id](params)
